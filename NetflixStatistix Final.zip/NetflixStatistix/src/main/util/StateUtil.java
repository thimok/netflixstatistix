package main.util;

public class StateUtil {
	public static boolean CANMOVE = false; // Boolean to set if the frame can be moved or not (Default: False, because it starts in Fullscreen)
	public static boolean FULLSCREEN = true; // Boolean to set if the frame is in 'Fullscreen-mode'
}
