package main;

public class Main {
	
	public static void main(String[] args) {
		//Instantiate an new mainframe on startup
		new MainFrame();
	}
}
